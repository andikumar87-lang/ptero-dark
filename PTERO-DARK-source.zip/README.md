# PTERO DARK

Android WebView wrapper for multiple HTTPS Pterodactyl panel URLs.

## Features in this starter
- Add, edit, remove, and save multiple panel addresses locally.
- Open the original panel login page inside Android WebView.
- JavaScript, DOM storage, WebSocket support through Chromium WebView.
- File chooser support for panel uploads.
- Back navigation and HTTPS-only navigation policy.
- No panel password or API key is collected by this app.

## Build APK without a PC
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build PTERO DARK APK** and run it (or push to `main`).
4. Open the completed workflow run, download `ptero-dark-debug-apk`.
5. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Important limitations
- This is a starter build, not yet tested against every Pterodactyl fork or custom theme.
- Panel websites must use valid HTTPS. HTTP is intentionally blocked.
- WebView uses Android's installed Chromium implementation; behavior may vary by Android/WebView version.
- The app does not bypass panel authentication, permissions, 2FA, or server restrictions.
- The current download handler hands download links to Android's external viewer/browser; in-app download management is a future improvement.
- Android WebView's cookie store is shared by WebView instances. Different hostnames keep their cookies separated by normal web origin rules, but multiple accounts on the same hostname may share session state.
- For release distribution, configure app signing and review security/privacy requirements.
