package com.indra.pterodark

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class Panel(val name: String, val url: String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ptero_dark", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var webView: WebView? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequestCode = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(android.graphics.Color.rgb(9, 14, 25))
        window.setNavigationBarColor(android.graphics.Color.rgb(9, 14, 25))
        window.decorView.systemUiVisibility = 0
        CookieManager.getInstance().setAcceptCookie(true)
        showPanelList()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(android.graphics.Color.rgb(9, 14, 25))
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun panels(): MutableList<Panel> {
        val out = mutableListOf<Panel>()
        val arr = try { JSONArray(prefs.getString("panels", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name")
            val url = o.optString("url")
            if (name.isNotBlank() && url.isNotBlank()) out.add(Panel(name, url))
        }
        return out
    }

    private fun savePanels(items: List<Panel>) {
        val arr = JSONArray()
        items.forEach { p -> arr.put(JSONObject().put("name", p.name).put("url", p.url)) }
        prefs.edit().putString("panels", arr.toString()).apply()
    }

    private fun showPanelList() {
        webView = null
        root = baseLayout()
        root.addView(text("PTERO DARK", 27f, -1, true))
        root.addView(text("UNIVERSAL PANEL • MULTI-PANEL", 12f, 0xFF91A4C2.toInt()))
        root.addView(button("+ Tambah Panel") { addPanelDialog() })
        val list = panels()
        if (list.isEmpty()) {
            root.addView(text("Belum ada panel. Tambahkan alamat panel Pterodactyl lu untuk mulai.", 15f, 0xFFD0D8E5.toInt()))
        } else {
            list.forEachIndexed { index, panel ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    setBackgroundColor(0xFF152238.toInt())
                }
                card.addView(text(panel.name, 18f, -1, true))
                card.addView(text(panel.url, 12f, 0xFF9FB0C8.toInt()))
                card.addView(button("BUKA PANEL") { openPanel(panel) })
                card.addView(button("Edit / Hapus") { managePanelDialog(index, panel) })
                val params = LinearLayout.LayoutParams(-1, -2)
                params.topMargin = dp(10)
                root.addView(card, params)
            }
        }
        root.addView(text("Login dilakukan di halaman panel resmi. Jangan bagikan password atau API key.", 12f, 0xFF91A4C2.toInt()))
        setContentView(root)
    }

    private fun addPanelDialog(existingIndex: Int? = null, existing: Panel? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val nameInput = EditText(this).apply {
            hint = "Nama panel (contoh: Panel VPS)"
            setSingleLine(true)
            setText(existing?.name ?: "")
        }
        val urlInput = EditText(this).apply {
            hint = "https://panel.domain.com"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(existing?.url ?: "")
        }
        box.addView(nameInput)
        box.addView(urlInput)
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Tambah panel" else "Edit panel")
            .setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                val name = nameInput.text.toString().trim()
                var url = urlInput.text.toString().trim()
                if (url.isNotEmpty() && !url.contains("://")) url = "https://$url"
                val uri = try { Uri.parse(url) } catch (_: Exception) { null }
                if (name.isBlank() || uri?.scheme != "https" || uri.host.isNullOrBlank()) {
                    Toast.makeText(this, "Isi nama dan URL HTTPS yang valid.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val items = panels()
                val panel = Panel(name, uri.toString().trimEnd('/'))
                if (existingIndex == null) items.add(panel) else items[existingIndex] = panel
                savePanels(items)
                showPanelList()
            }.show()
    }

    private fun managePanelDialog(index: Int, panel: Panel) {
        AlertDialog.Builder(this)
            .setTitle(panel.name)
            .setItems(arrayOf("Edit", "Hapus")) { _, which ->
                if (which == 0) addPanelDialog(index, panel)
                else AlertDialog.Builder(this)
                    .setMessage("Hapus ${panel.name} dari daftar aplikasi? Ini tidak menghapus server atau akun panel.")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus") { _, _ ->
                        val items = panels()
                        if (index in items.indices) items.removeAt(index)
                        savePanels(items)
                        showPanelList()
                    }.show()
            }.show()
    }

    private fun openPanel(panel: Panel) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https") return false
                if (uri.scheme == "http") {
                    Toast.makeText(this@MainActivity, "Koneksi HTTP tidak diizinkan. Gunakan HTTPS.", Toast.LENGTH_LONG).show()
                    return true
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileCallback?.onReceiveValue(null)
                this@MainActivity.fileCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    startActivityForResult(intent, fileRequestCode)
                    true
                } catch (_: Exception) {
                    this@MainActivity.fileCallback?.onReceiveValue(null)
                    this@MainActivity.fileCallback = null
                    false
                }
            }
        }
        web.setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Tidak ada aplikasi untuk membuka unduhan ini.", Toast.LENGTH_SHORT).show()
            }
        })
        web.setBackgroundColor(android.graphics.Color.rgb(9, 14, 25))

        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(9, 14, 25))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val back = Button(this).apply {
            text = "‹ Panel"
            isAllCaps = false
            setOnClickListener { web.stopLoading(); web.destroy(); showPanelList() }
        }
        val title = TextView(this).apply {
            text = panel.name
            textSize = 15f
            setTextColor(-1)
            setPadding(dp(8), 0, 0, 0)
        }
        bar.addView(back)
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        screen.addView(bar)
        screen.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        webView = web
        setContentView(screen)
        web.loadUrl(panel.url)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequestCode) {
            val result = if (resultCode == Activity.RESULT_OK && data != null) {
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            } else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    override fun onBackPressed() {
        val web = webView
        if (web != null && web.canGoBack()) web.goBack() else if (web != null) {
            web.stopLoading()
            web.destroy()
            showPanelList()
        } else super.onBackPressed()
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        webView?.destroy()
        super.onDestroy()
    }
}
